## gsutil 명령어

- 파일을 읽을 수 있게 만들고 목록 허용하게 해주는 명령어
- gsutil iam ch allUsers:objectViewer gs//bucket-name
package org.kitsoft.healpy.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import org.kitsoft.healpy.myapplication.R;

public class MemberInfor extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member_information);
    }
}
